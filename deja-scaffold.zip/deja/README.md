# Déjà — incident copilot with institutional memory (Neo4j)
Neo4j × hackFront India **Graph Builder Build Sprint, Bengaluru** · Sat 17 Oct 2026 · Quad AI, HSR Layout · **submission window 11:30 AM–4:30 PM IST**

> Teams keep re-learning what the organisation already knew. Déjà turns incidents, deploys, services, owners and fixes into a graph that surfaces hidden risk and recalls what worked, what failed, and what was true at any date.

## Status
| Piece | State |
|---|---|
| **1. API contract** — Pydantic schemas → `contract/openapi.json` → generated TS types + typed client + real example responses | ✅ done, frozen |
| **Reference engine + mock server** — every endpoint works in-memory, incl. the full demo script via `/chat` | ✅ done |
| **3. Seed data** — 22 services, 44 incidents, 36 deploys, 67 attempts, ownership history, with a **planted story** | ✅ done |
| Neo4j loader, schema, verifier | ✅ written · ⚠️ **never run against a live Neo4j/Aura** (no DB in the build sandbox) — run `load_seed` + `verify_seed` first thing |
| `Neo4jEngine`, LLM chat agent, frontend app, demo polish | ⏳ see `docs/TASKS.md` (Antigravity prompts included) |

## Quick start
```bash
cd backend && pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000     # mock mode, zero setup → http://localhost:8000/docs
python -m pytest -q                            # 11 tests: seed story + contract + full demo script
# Neo4j:
cp ../.env.example ../.env                     # fill NEO4J_*; keep MODE=mock until Neo4jEngine is done
python -m scripts.load_seed --wipe && python -m scripts.verify_seed
```
Try it: `curl -X POST localhost:8000/chat -H 'content-type: application/json' -d '{"session_id":"a","message":"checkout latency is spiking"}'`

## Layout
```
AGENTS.md              rules + context for AI coding agents          docs/TASKS.md        work split + prompts
docs/API_CONTRACT.md   endpoints + scoring rules (frozen)           docs/GRAPH_MODEL.md  schema + reference Cypher
contract/              openapi.json + examples/*.json (real responses)
data/                  seed.json · expected_insights.json · schema.cypher
backend/app/           schemas.py (contract) · engine.py (interface) · mock_engine.py (reference) · neo4j_engine.py (TODO)
                       chat.py (rule-based mock; TODO LLM) · api.py · main.py
backend/scripts/       generate_seed · load_seed · verify_seed · export_contract
backend/tests/         test_seed_story · test_contract · test_parity_neo4j (auto-skips without NEO4J_URI)
frontend/src/api/      types.ts (generated) · client.ts (typed fetch client)   ← the app itself is T3
```

## The planted story (why the demo lands)
- `payments-api` is **tier-2**, only **#6 by fan-in** (infra like redis/kafka rank higher) and `checkout` has more *own* incidents — but fan-in **and** incident memory together make it the **#1 risk** (33 vs 21).
- `restart-pods` failed **5/5** on payments-api incidents, `rollback-deploy` worked **5/5** → agent says *avoid restart*.
- A fresh *checkout latency* alert traces upstream to payments-api (deploy **v2.3.1 by Asha**, 3 days ago); a decoy (inventory v4.8.0) ranks 2nd.
- Ownership time travel: payments-api stays with Asha so the live demo can reassign to Ravi, then ask "who owned it in July?" → Asha. (`search` and `refunds` have pre-seeded ownership changes.)

## Maintenance
```bash
python -m scripts.generate_seed        # regenerates data/seed.json + expected_insights.json (deterministic)
python -m scripts.export_contract      # after any intentional contract change
npx openapi-typescript contract/openapi.json -o frontend/src/api/types.ts   # run from repo root
```
